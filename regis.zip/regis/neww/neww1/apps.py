from django.apps import AppConfig


class Neww1Config(AppConfig):
    name = 'neww1'
