from django.db import models

class detail(models.Model):
    fname=models.CharField(max_length=20)
    lname = models.CharField(max_length=20)
    phone=models.IntegerField()
    email=models.CharField(max_length=20)
    password=models.CharField(max_length=10)

