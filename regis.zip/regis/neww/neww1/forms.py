from django import forms

class data(forms.Form):
    fname = forms.CharField(max_length=20)
    lname = forms.CharField(max_length=20)
    phone = forms.IntegerField()
    email = forms.CharField(max_length=20)
    password = forms.CharField(max_length=10)


class logdata(forms.Form):
    email = forms.CharField(max_length=20)
    password = forms.CharField(max_length=10)

