from django.contrib import admin
from .models import detail

admin.site.register(detail)

