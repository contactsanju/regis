from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from .forms import *

def index(request):
    return render(request, 'index.html')

def newww(request):
    return render(request, 'register.html')


def test3(request):
    return render(request, 'forgot-password.html')

def reg(request):
 if request.method == 'POST':
    a=data(request.POST)
    if a.is_valid():
        fname=a.cleaned_data['fname']
        lname = a.cleaned_data['lname']
        phone=a.cleaned_data['phone']
        email=a.cleaned_data['email']
        password=a.cleaned_data['password']
        b=detail(fname=fname,lname=lname,phone=phone,email=email,password=password,)
        b.save()
        return redirect(log)
    else:
        return HttpResponse('registration incomplte')
 else:
     return render(request,'register.html')


def log(request):
    if request.method == 'POST':
        a=logdata(request.POST)
        if a.is_valid():
            email=a.cleaned_data['email']
            password=a.cleaned_data['password']

            b = detail.objects.all()
            for i in b:
                if email== i.email and password== i.password :
                    return HttpResponse('successfully login')
            else:
                return HttpResponse('invalid user')
    else:
        return render(request, 'index.html')